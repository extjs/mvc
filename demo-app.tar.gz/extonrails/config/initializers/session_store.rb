# Be sure to restart your server when you modify this file.

# Your secret key for verifying cookie session data integrity.
# If you change this key, all old sessions will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.session = {
  :key         => '_extonrails_session',
  :secret      => '24f85aa5bcf8ce8c474bd3760e197fc2bca651f1c796c341a8d3c2dddaf3e5d53998be7c94681729e3c08728194cab74ffb85afce95bac9f2168b82af5038a20'
}

# Use the database for sessions instead of the cookie-based default,
# which shouldn't be used to store highly confidential information
# (create the session table with "rake db:sessions:create")
# ActionController::Base.session_store = :active_record_store
