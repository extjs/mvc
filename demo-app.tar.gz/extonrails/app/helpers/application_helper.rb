# Methods added to this helper will be available to all templates in the application.
module ApplicationHelper

  def render_store(model, config)

    name = model.to_s.downcase.pluralize
    format = (config[:format].nil? ? "json" : config.delete(:format)).capitalize
    config[:successProperty] = 'success' if config[:autoLoad].nil?
    config[:autoLoad] = true if config[:autoLoad].nil?
    config[:autoSave] = false if config[:autoSave].nil?
    config[:idProperty] = model.columns.find {|c| c.primary}.name
    config[:storeId] = name if config[:storeId].nil?
    config[:root] = name if config[:root].nil?
    config[:url] = '/' + name if config[:url].nil?
    config[:fields] = model.columns.reject {|c| c.primary }.collect {|c|
      col = {:name => c.name, :allowBlank => c.null, :type => c.type}
      col[:dateFormat] = config[:dateFormat].nil? ? "c" : config[:dateFormat].kind_of?(Hash) && !config[:dateFormat][c.name].nil? ? config[:dateFormat][c.name] : config[:dateFormat] if c.type === :datetime || c.type === :date
      col
    }
    "new Ext.data.#{format}Store(#{config.to_json});"
  end
end
