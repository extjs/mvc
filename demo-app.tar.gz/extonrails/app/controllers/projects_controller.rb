class ProjectsController < ApplicationController
  include ExtJS::Controller
  include Rails::ExtJS::Direct::Controller
  helper ExtJS::Helpers::Store
  helper ExtJS::Helpers::Component

  def step1
    render
  end
  def step2
    render
  end
  def step3
    render
  end
  def step4
    render
  end

  def index
     render
  end
end
