class User < ActiveRecord::Base
  include ExtJS::Model

  extjs_fields :id, :first, :last, :email, :created_at, :updated_at

end
