users.Editor = Ext.extend(Ext.Window, {

    storeId: null,
    autoHeight: true,
    layout: 'fit',
    closeAction: 'hide',
    closable: true,

    initComponent : function() {
        this.items = this.build();
        var store = Ext.StoreMgr.get(this.storeId);
        users.Editor.superclass.initComponent.call(this);
    },

    build : function() {
        return {
            xtype: 'form',
            autoHeight: true,
            items: [{
                xtype: 'textfield',
                bodyStyle: 'padding: 10px',
                fieldLabel: 'First',
                name: 'first'
            }]
        }
    },

    loadRecord : function(rec) {
        this.record = rec;
        this.items.first().getForm().loadRecord(rec);
    }
});
Ext.reg('users-editor', users.Editor);
