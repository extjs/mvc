/**
 * users.ComboBox
 * Extend to provide 'user' store.
 */
users.ComboBox = Ext.extend(Ext.form.ComboBox, {
    displayField: 'email',
    valueField: 'id',
    mode: 'local',
    forceSelection: true,
    triggerAction: 'all',
    initComponent : function() {
        this.store = Ext.StoreMgr.get(this.storeId);
        users.ComboBox.superclass.initComponent.call(this);
    }
});
Ext.reg('users-combo', users.ComboBox);