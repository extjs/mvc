HomeController = function() {
    items = [];

    return {
        add : function(item) {
            items.push(item);
        },

        run : function() {
            new Ext.Viewport({
                layout: 'border',
                items: items
            })
        }
    }
}();
