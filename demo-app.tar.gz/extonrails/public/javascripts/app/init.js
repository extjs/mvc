Ext.ns('Ext.ux', 'Ext.ux.plugins');

var App = new Ext.ux.App({});

