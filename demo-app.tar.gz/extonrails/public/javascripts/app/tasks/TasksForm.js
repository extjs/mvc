/**
 * @class tasks.FormPanel
 * Note:  This class could be implemented as a base-class or plugin instead since it's so generalized.
 */
tasks.FormPanel = Ext.extend(Ext.form.FormPanel, {
    /**
     * @cfg {String} saveText [Save]
     */
    saveText: 'Save',
    /**
     * @cfg {String} saveIcon [silk-disk]
     */
    saveIcon: 'silk-disk',
    /**
     * @cfg {String} cancelText [Back]
     */
    cancelText: 'Back',
    /**
     * @cfg {String} cancelIcon [silk-arrow-left]
     */
    cancelIcon: 'silk-arrow-left',
    /**
     * @cfg {String} storeId
     */
    storeId: undefined,
    /**
     * @cfg {Ext.data.Record} record
     */
    record: null,

    initComponent : function() {
        this.tbar = this.buildUI();

        // bind a Store to the form.  Fire the "form-save" event when write-actions are successful
        this.store = Ext.StoreMgr.lookup(this.storeId);
        this.store.on('beforewrite', function(proxy, action) {
            // quick and dirty verb present-tense inflector.
            var verb = (action[action.length-1] === 'e') ? action.substr(0, action.length-1) + 'ing' : action + 'ing';
            this.mask.msg = verb + ' record.  Please wait...';
            this.mask.show();
        },this);
        this.store.on('write', function(proxy, action) {
            this.mask.hide();
            this.fireEvent('form-save', this);
        },this);

        // The toolbar & events here should be implemented as a plugin instead.
        this.addEvents(
            /**
             * @event form-save
             */
            'form-save',
            /**
             * @event form-cancel
             */
            'form-cancel'
        );

        tasks.FormPanel.superclass.initComponent.call(this);
    },

    afterRender : function() {
        // create a LoadMask for user-feedback messages.
        tasks.FormPanel.superclass.afterRender.call(this);
        this.mask = new Ext.LoadMask(this.el, {msg: 'Saving'});
    },

    buildUI : function() {
        return [{
            text: this.cancelText,
            iconCls: this.cancelIcon,
            handler: this.onCancel.createDelegate(this)
        }, '-', '->', '-', {
            text: this.saveText,
            iconCls: this.saveIcon,
            handler: this.onSave.createDelegate(this)
        }]
    },

    loadRecord: function(record) {
        this.record = record;
        this.setTitle('Edit Task: ' + record.data.title);
        this.getForm().loadRecord(record);
    },

    reset: function() {
        this.record = null;
        this.getForm().reset();
        this.setTitle('Create new task');
    },

    onCancel : function(btn, ev) {
        this.fireEvent('form-cancel', this, ev);
    },

    onSave : function(btn, ev) {
        var form = this.getForm();
        // First, validate the form...
        if (!form.isValid()) {
            Ext.Msg.alert('Error', 'Form is invalid');
            return false;
        }

        // She's all good.
        if (this.record === null) { // -- CREATE
            var Task = this.store.recordType;
            this.store.add(new Task(form.getValues()));
        } else {    // -- UPDDATE
            form.updateRecord(this.record);
        }
    }
});
Ext.reg('tasks-form', tasks.FormPanel);
