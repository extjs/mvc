place your Ext-3.0.1+ here.  adjust app/views/layouts/application.html.erb accordingly.
http://www.extjs.com

