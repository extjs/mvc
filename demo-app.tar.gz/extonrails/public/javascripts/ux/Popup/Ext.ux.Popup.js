/**
 * Ext.ux.Popup
 * @author Chris Scott <christocracy@gmail.com>
 */
Ext.ux.Popup = Ext.extend(Ext.menu.Menu, {
    cls: 'x-menu-popup',
    bodyStyle: 'padding: 0',
    forceLayout: true,
    initComponent : function() {
        this.items = this.build();
        Ext.ux.Popup.superclass.initComponent.call(this);
    },
    show : function() {
        Ext.ux.Popup.superclass.show.apply(this, arguments);
        this.getFormPanel().getForm().reset();
        this.doLayout();
    },
    getFormPanel : function() {
        return this.items.first();
    },
    build : Ext.emptyFn
});
Ext.reg('ext-ux-popup', Ext.ux.Popup);
