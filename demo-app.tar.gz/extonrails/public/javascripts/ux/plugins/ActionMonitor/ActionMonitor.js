/**
 * Ext.ux.plugins.ActionMonitor
 * A class for listening and responding to links having attribute "ext:action", eg:
 * <a href="#" ext:action="reply">Reply</a>
 */
Ext.ux.plugins.ActionMonitor = function(params) {
    Ext.apply(this, params);
};
Ext.ux.plugins.ActionMonitor.prototype = {
    /**
     * @cfg {String} actionSelector [a]
     * type of domNode to listen-to
     */
    actionSelector : 'a',
    /**
     * @cfg {Object} actions {}
     * A hash of actions to listen-to
     */
    actions: {},
    /**
     * @cfg {Function} handler
     * A general handler for any action without a function defined
     */
    handler: Ext.emptyFn,

    // private, reference to the plugin's parent
    klass : null,

    /**
     * init
     * @param {Ext.Component} klass
     */
    init : function(klass) {
        this.klass = klass;
        klass.on('render', this.initEvents, this);
    },

    /**
     * initEvents
     * @param {Ext.Component} klass
     */
    initEvents : function(klass) {
        klass.mon(klass.el, 'click', this.processClick, this);
    },

    // private processClick
    processClick : function(e) {
        var el = e.getTarget(this.actionSelector, this.klass.el, true);
        if(el){
            var action = el.getAttributeNS('ext', 'action');
            if (action) {
                e.preventDefault();
                this.handler.call(this.klass, action, el, e);
            }
        }
    }
};

