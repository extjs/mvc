Ext.namespace('ExtJs.DataView');

/**
 * ExtJs.DataView.Orderable
 * A DataView plugin for draggable re-ordering of records
 * @author Chris Scott
 */
ExtJs.DataView.Orderable = function(params) {
    this.addEvents({
        /**
         * @event edit fires when "edit" link is pressed
         * @param {DataView} view
         * @param {Number} startIndex
         * @param {Records[]} affected records from dragIndex -> dropIndex
         */
        'order' : true
    });

    // add supplied listeners
    if (!Ext.isEmpty(params.listeners)) {
        this.on(params.listeners);
    }
}
Ext.extend(ExtJs.DataView.Orderable, Ext.util.Observable, {

    /**
     * @cfg {String}
     * Css class to apply to valid dropZone
     * @param {Object} panel
     */
    dropZoneCls: 'orderable-dropzone',

    init : function(panel) {
        var vw = panel.getView();
        vw.on('render', function(view) {
            // once rendered, make sure this view offers scrolling as part of the drag drop shit
            Ext.applyIf(view, {
                dropZoneCls: this.dropZoneCls
            });
            this.initDraggables(view);
            this.initDroppables(view);
        }, this);
    },

    initDraggables : function(view) {
        view.dragZone = new Ext.dd.DragZone(view.getEl(), {
            containerScroll: true,

            // On receipt of a mousedown event, see if it is within a draggable element.
            // Return a drag data object if so. The data object can contain arbitrary application
            // data, but it should also contain a DOM element in the ddel property to provide
            // a proxy to drag.
            getDragData: function(e) {
                var sourceEl = e.getTarget(view.itemSelector);
                if (sourceEl) {
                    d = sourceEl.cloneNode(true);
                    d.id = Ext.id();
                    return view.dragData =  {
                        sourceEl: sourceEl,
                        repairXY: Ext.fly(sourceEl).getXY(),
                        ddel: d,
                        record: view.getRecord(sourceEl) // <-- hack 1 for index
                    }
                }
            },

            // Provide coordinates for the proxy to slide back to on failed drag.
            // This is the original XY coordinates of the draggable element.
            getRepairXY: function() {
                return this.dragData.repairXY;
            }
        });
    },

    /*
     * Here is where we "activate" the GridPanel.
     * We have decided that the element with class "hospital-target" is the element which can receieve
     * drop gestures. So we inject a method "getTargetFromEvent" into the DropZone. This is constantly called
     * while the mouse is moving over the DropZone, and it returns the target DOM element if it detects that
     * the mouse if over an element which can receieve drop gestures.
     *
     * Once the DropZone has been informed by getTargetFromEvent that it is over a target, it will then
     * call several "onNodeXXXX" methods at various points. These include:
     *
     * onNodeEnter
     * onNodeOut
     * onNodeOver
     * onNodeDrop
     *
     * We provide implementations of each of these to provide behaviour for these events.
     */
    initDroppables : function(view) {
        var self = this;
        view.dropZone = new Ext.dd.DropZone(view.getEl(), {

            defaultPadding: {
                left: 0,
                right: 0,
                top: 5,
                bottom: 5
            },

            // If the mouse is over a target node, return that node. This is
            // provided as the "target" parameter in all "onNodeXXXX" node event handling functions
            getTargetFromEvent: function(e) {
                return e.getTarget(view.itemSelector);
            },

            // On entry into a target node, highlight that node.
            onNodeEnter : function(target, dd, e, data){
                Ext.fly(target).addClass(view.dropZoneCls);
            },

            // On exit from a target node, unhighlight that node.
            onNodeOut : function(target, dd, e, data){
                Ext.fly(target).removeClass(view.dropZoneCls);
            },

            // While over a target node, return the default drop allowed class which
            // places a "tick" icon into the drag proxy.
            // thing is, self is not a good target node for dropping...
            onNodeOver : function(target, dd, e, data){
				var targetRecord = view.getRecord(target);
                return (targetRecord.data.id != view.dragData.record.data.id)? Ext.dd.DropZone.prototype.dropAllowed : Ext.dd.DropZone.prototype.dropNotAllowed;
            },

            // On node drop, we can interrogate the target node to find the underlying
            // application object that is the real target of the dragged data.
            // In this case, it is a Record in the GridPanel's Store.
            // We can use the data set up by the DragZone's getDragData method to read
            // any data we decided to attach.
            onNodeDrop : function(target, dd, e, data) {

                if ( view.getRecord(target).id == data.record.id) {
                    return false;        // don't drop a record on yourself!!
                }

                // calculate the dragIndex, and remove the record, noting we may have to re-insert
                // the record back into the store at the same place if we dropped on this original node
                var dragIndex = view.store.indexOf(data.record);
                view.store.remove(data.record);

                var dropRecord = view.getRecord(target);
                var dropIndex = view.store.indexOf(dropRecord);

                if (dropIndex < 0) {
                    dropIndex = 0;
                }
                if (dragIndex <= dropIndex) {
                    dropIndex++;
                }
                var dragRecord = view.store.insert(dropIndex, data.record);
                view.select(dropIndex);

                var index = dragIndex;
                var rs = null;
                if (dragIndex > dropIndex) {
					index = dropIndex;
                    rs = view.store.getRange(dropIndex, dragIndex);
                }
                else {
                    rs = view.store.getRange(dragIndex, dropIndex);
                }
                self.fireEvent('order', view, data.record, dropRecord, dropIndex);

            }
        });
    }
});