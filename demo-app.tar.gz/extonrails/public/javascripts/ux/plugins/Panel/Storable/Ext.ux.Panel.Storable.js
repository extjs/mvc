Ext.ns('Ext.ux.Panel');
/**
 * Ext.ux.plugins.Storable
 * A FormPanel plugin adding common [save][cancel] buttons along with a handler to accept a Store
 * intance to add new records to
 */
Ext.ux.Panel.Storable = function(config){
    Ext.apply(this, config);
}
Ext.ux.Panel.Storable.prototype = {
    /**
     * @cfg {String} saveText [Save]
     */
    saveText: 'Save',
    /**
     * @cfg {String} cancelText [Cancel]
     */
    cancelText: 'Cancel',

    init : function(panel) {
        if (typeof(panel.reset) === 'function') {
            panel.reset = panel.reset.createSequence(this.reset, panel);
        } else {
            panel.reset = this.reset.createDelegate(panel);
        }
        if (typeof(panel.bind) === 'function') {
            panel.bind = panel.pind.createSequence(this.bind, panel);
        } else {
            panel.bind = this.bind.createDelegate(panel);
        }
        if (typeof(panel.loadRecord) === 'function') {
            panel.loadRecord = panel.loadRecord.createSequence(this.loadRecord, panel);
        } else {
            panel.loadRecord = this.loadRecord.createDelegate(panel);
        }
        // TODO: check of existing buttons?
        panel.buttons = this.buildUI(panel);

        // Add Storable events
        panel.addEvents('storable-save', 'storable-cancel');

        if (this.storeId) {
            panel.bind(Ext.StoreMgr.get(this.storeId));
        }
    },

    buildUI: function(scope) {
        return [{
            text: this.saveText,
            handler: this.onSave.createDelegate(scope)
        }, {
            text: this.cancelText,
            handler: this.onCancel.createDelegate(scope)
        }]
    },

    onSave: function() {
        if (typeof(this.getForm) === 'function') {
            var form = this.getForm();
            if (this.record) {
                form.updateRecord(this.record);
            }
            else {
                this.store.add(new this.store.recordType(form.getValues()));
            }
        }
        this.fireEvent('storable-save', this);
    },

    onCancel: function() {
        this.fireEvent('storable-cancel', this);
    },

    /**
     * binds a Store to the panel
     * @param {Object} store
     */
    bind : function(store) {
        this.record = null;
        this.store = store;
    },
    /**
     * initiates an "edit record" action
     * @param {Object} record
     */
    loadRecord : function(record) {
        if (typeof(this.getForm) === 'function') {
            var form = this.getForm();
            form.reset();
            this.record = record;
            form.loadRecord(this.record);
        }
    },
    /**
     * resets the panel.
     * @param {Object} params
     */
    reset : function(params) {
        this.record = null;
        if (typeof(this.getForm) === 'function') {
            this.getForm().reset();
        }
    }
};
Ext.preg('panel-storable', Ext.ux.Panel.Storable);
