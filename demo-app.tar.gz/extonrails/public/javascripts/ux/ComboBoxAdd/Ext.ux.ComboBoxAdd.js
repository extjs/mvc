
/**
 * Ext.ux.ComboBoxAdd
 * a Combination of both ComboBox and TwinTriggerField.
 * adds an "add" button beside std combo Box trigger.
 * @author Chris Scott
 *
 */
Ext.ux.ComboBoxAdd = Ext.extend(Ext.form.ComboBox, {

    /***
     * trigger classes.
     */
    trigger1Class: '',
    trigger2Class: 'x-form-add-trigger',

    /** @config {Boolean} hides the regular combo trigger **/
    hideTrigger1 : false,

    /** @config [Boolean} hides the add trigger **/
    hideTrigger2 : false,

    /***
     * initComponent
     */
    initComponent : function(){
        Ext.ux.ComboBoxAdd.superclass.initComponent.call(this);

        /***
         * @event add
         * fires when 2nd trigger is clicked
         */
        this.addEvents({add : true});

        // implement triggerConfig from Ext.form.TwinTriggerField
        this.triggerConfig = {
            tag:'span', cls:'x-form-twin-triggers', cn:[
            {tag: "img", src: Ext.BLANK_IMAGE_URL, cls: "x-form-trigger " + this.trigger1Class},
            {tag: "img", src: Ext.BLANK_IMAGE_URL, cls: "x-form-trigger " + this.trigger2Class}
        ]};
    },

    /***
     * onRender
     * provide a mechanism to hide either triggers
     * @param {Object} ct
     * @param {Object} position
     */
    onRender : function(ct, position) {
        Ext.ux.ComboBoxAdd.superclass.onRender.call(this, ct, position);
        if (this.hideTrigger1 === true) { this.getTrigger(0).setDisplayed(false);}
        if (this.hideTrigger2 === true) { this.getTrigger(1).setDisplayed(false);}
    },

    /***
     * getTrigger
     * copied from Ext.form.TwinTriggerField
     * @param {Object} index
     */
    getTrigger : function(index){
        return this.triggers[index];
    },

    /***
     * initTrigger
     * copied from Ext.form.TwinTriggerField
     */
    initTrigger : function(){
        var ts = this.trigger.select('.x-form-trigger', true);
        this.wrap.setStyle('overflow');
        var triggerField = this;
        ts.each(function(t, all, index){
            t.hide = function(){
                var w = triggerField.wrap.getWidth();
                //this.dom.style.display = 'none';    // <-- commented out these lines.  they fuck things.
                triggerField.el.setWidth(w-triggerField.trigger.getWidth());
            };
            t.show = function(){
                var w = triggerField.wrap.getWidth();
                //this.dom.style.display = '';  // <-- commented out these lines.  they fuck things.
                triggerField.el.setWidth(w-triggerField.trigger.getWidth());
            };
            var triggerIndex = 'Trigger'+(index+1);

            if(this['hide'+triggerIndex]){
                //t.dom.style.display = 'none';  // <-- commented out these lines.  they fuck things.
            }
            t.on("click", this['on'+triggerIndex+'Click'], this, {preventDefault:true});
            t.addClassOnOver('x-form-trigger-over');
            t.addClassOnClick('x-form-trigger-click');
        }, this);
        this.triggers = ts.elements;
    },

    /***
     * onTrigger1Click
     * defer to std ComboBox trigger method
     */
    onTrigger1Click : function() {
        this.onTriggerClick();
    },

    /***
     * onTrigger2Click
     * this is the "add" [+] button handler.  fire 'add' event
     */
    onTrigger2Click : function(ev, node, options) {
        this.fireEvent('add', {field: this, button: this.triggers[1]});
        // NOTE: I've added a stopEvent here to prevent refocussing of popup (if this combo is on a popup)
        // since the [+] button usually show another popup or form, its parent popup was receiving the click
        // event and calling toFront(), refocussing over top of the newly shown form.
        // @see RExt.form.Popup::initialize -- there's a body element click-handler there that refocusses itself
        // when clicked.
        // Anyway -- this behaviour is not desired when we click on the [+] button -- we *want* the newly shown
        // form to appear on top of this one.
        ev.stopEvent();
    },

  /***
   * insert
   * provide a convenience method to insert ONE AND ONLY ONE record to the store.
   * @param {Object} index
   * @param {Object} data (
   */
  insert : function(index, data) {
        this.reset();

        var rec = new this.store.recordType(data);
        rec.id = rec.data.id;
        this.store.insert(index, rec);
    this.setValue(rec.data.id);
    this.fireEvent('select', this, rec, index);
        return rec;
  }
});