Ext.ns('Ext.ux', 'Ext.ux.Panel');
/**
 * Ext.ux.Panel.ToolbarSave
 * A simple form extension that automatically renders [save][cancel] buttons and fires events when they're pressed.
 * When [save] is clicked, event "form-save" is fired.
 * When [cancel] is clicked, event "form-cancel" is fired.
 * This would be better implemented as a plugin.
 */
Ext.ux.Panel.SaveToolbar = function(param) {
    Ext.apply(this, param);
}
Ext.ux.Panel.SaveToolbar.prototype = {
    /**
     * @cfg {String} saveText [Save]
     */
    saveText: 'Save',
    /**
     * @cfg {String} cancelText [Back]
     */
    cancelText: 'Back',

    init : function(panel) {
        console.info('panel: ', panel);

        panel.topToolbar = panel.createToolbar([{text:'foo'}]);

        panel.addEvents('toolbarsave', 'toolbarcancel');
    },

    buildToolbar : function() {
        return new Ext.Toolbar({
            items: [{
                text: this.cancelText,
                iconCls: 'silk-arrow-left',
                handler: this.onFormCancel.createDelegate(this)
            }, '-', '->', '-', {
                text: this.saveText,
                iconCls: 'silk-disk',
                handler: this.onFormSave.createDelegate(this)
            }]
        });
    },

    onFormSave : function() {
        this.fireEvent('toolbarsave', this);
    },

    onFormCancel : function() {
        this.fireEvent('toolbarcancel', this);
    }
};
Ext.preg('panel-savetoolbar', Ext.ux.Panel.SaveToolbar);

