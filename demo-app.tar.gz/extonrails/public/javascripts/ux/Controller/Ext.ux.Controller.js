Ext.ux.Controller = Ext.extend(Ext.util.MixedCollection({
    buildView : function() {
        return {
            xtype: 'viewport'
        };
    }
});
