/**
 * Ext.ux.NavPanel
 */
Ext.ux.NavPanel = Ext.extend(Ext.Panel, {
    autoHeight:true,
    baseCls:'x-plain',

    tpl: '<tpl for="."><h3>{title}</h3><dl style="margin-bottom:15px;"><tpl for="links"><dd><a href="{url}" ext:action="{action}" target="{target}">{text}</a></dd></tpl> </dl></tpl>',

    /**
     * @cfg {String} tplId
     * templateId
     */
    tplId : 'nav-tpl',

    /**
     * @cfg {Object} data
     * navigation data for XTemplate
     */
    data: {},

    /**
     * @cfg {String} actionSelector [a]
     * type of domNode to listen-to
     */
    actionSelector : 'a',
    /**
     * @cfg {Object} actions {}
     * A hash of actions to listen-to
     */
    actions: {},
    /**
     * @cfg {Function} handler
     * A general handler for any action without a function defined
     */
    handler: Ext.emptyFn,

    // private processClick
    processClick : function(e) {
        var el = e.getTarget(this.actionSelector, this.el, true);
        if(el){
            var action = el.getAttributeNS('ext', 'action');
            if (action) {
                e.preventDefault();
                this.handler.call(this, action, el, e);
            }
        }
    },

    initComponent : function() {
        this.addEvents({
            click : true,

            /**
             * extaction
             * fired when one of these is clicked: <a ext:action="foo">Ext Action</a>
             * @param {String} id the ext:action payload
             * @param {Element} el
             * @param {Event} ev
             */
            extaction: true
        });

        this.on('render', function() {
            this.mon(this.el, 'click', this.processClick, this);
        }, this);

        Ext.ux.NavPanel.superclass.initComponent.call(this);
    },

    /**
     * onExtAction
     * @param {String} id
     * @param {Object} el
     * @param {Object} e
     */
    onExtAction : function(id, el, e) {
        e.preventDefault();
        this.setActive(el, e);
        this.fireEvent('extaction', id, el, e);
    },

    onRender : function(){
        Ext.ux.NavPanel.superclass.onRender.apply(this, arguments);
        this.tpl = new Ext.XTemplate(this.tpl);
        this.tpl.overwrite(this.body, this.data);
    },

    setActive : function(el, e){
        //return true;
        var p = Ext.fly(el).parent();
        if (p.hasClass('active')) {
            return false;
        } else {
            p.radioClass('active');
            return true;
        }
    }
});