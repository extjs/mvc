/**
 * Ext.ux.MainView
 * copied from Support app.
 */
Ext.ux.MainView = Ext.extend(Ext.Panel, {
    baseCls: 'x-bubble',
    layout:'card',
    autoHeight:true,
    activeItem: 0,
    frame:true,

    currentView : null,

    /**
     * @cfg {Array} views
     * lists of available view components
     */
    views : [],

    initComponent : function() {
        var views = new Ext.util.MixedCollection();
        views.addAll(this.views);
        this.views = views;

        this.addEvents({
            /**
             * @event viewclose
             * Fires when the current view fires its 'cancel' method
             */
            'viewclose' : true,

            'viewchange' : true
        })
        Ext.ux.MainView.superclass.initComponent.call(this);
    },

    changeTo: function(id){
        //$Mk.focus();	// <-------------------------------------- WHAT IS THIS??

        var o = this.items.get(id);
        if(o){

            if (this.layout.activeItem != o) {
                this.layout.setActiveItem(o);
            }else{
                if(o.doRefresh){
                    o.doRefresh();
                }else if(o.store){
                    o.store.reload();
                }
            }

        }else{
            o = this.buildItem(id);

            // return false if no item returned, ie: item is not available in UI
            if (!o) {
                return false;
            }
            this.add(o);
            this.layout.setActiveItem(o);
        }
        this.currentView = o.id;
        this.fireEvent('viewchange', o);
        return o;
    },

    change: function(item, preventEvent){
        //$Mk.focus();
        if (item.ownerCt != this) {
            this.add(item);
        }
        this.layout.setActiveItem(item);
        if (!preventEvent) {
            this.fireEvent('viewchange', item.id);
        }
    },

    showTicket : function(ticket) {
        var p = this.items.get('ticket-panel');
        if(!p){
            p = this.buildItem('ticket-panel');
            if (!p) {
                return false;
            }
            this.change(p, true);
            p.setTicket(ticket);
        }else{
            p.setTicket(ticket);
            this.change(p, true);
        }
        this.fireEvent('viewchange', 'ticket-'+p.tid);
    },

    showSubscription : function(s){
        var p = this.items.get('subscription-form');
        if(!p){
            p = new tix.SubscriptionForm();
            this.change(p, true);
            p.setSubscription(s);
        }else{
            p.setSubscription(s);
            this.change(p, true);
        }
        if(s) {
            this.fireEvent('viewchange', 'sp-' + p.sid);
        }
    },

    showItem : function(formId, item){
        var p = this.items.get(formId);
        if(!p){
            p = this.buildItem(formId);
            if (!p) {
                // return false if buidlItem didn't return an object (ie: item doesn't exist in this UI)
                return false;
            }
            this.change(p, true);
            p.setItem(item);
        }else{
            p.setItem(item);
            this.change(p, true);
        }
        if(item) {
            this.fireEvent('viewchange', p.xtype);
        }
    },

    buildItem : function(id) {
        var item = this.views.find(function(item){ return (item.id == id) ? true : false; });
        if (!item) {
            throw new Error("MainView could not build item named '" + id + "'");
        }

        var panel = Ext.ComponentMgr.create(Ext.apply(item, {
            frame: false,
            border: false,
            plugins: {
                init : function(klass) {
                    // override close method to simply fire close event.
                    klass.close = function() {
                        klass.fireEvent('close', klass);
                    }
                }
            }
        }));
        // listen to close event, fired by attached plugin above.
        this.relayEvents(panel, ['actioncomplete', 'select', 'close']);

        return panel;
    },

    onRender : function(){
        Ext.ux.MainView.superclass.onRender.apply(this, arguments);

        this.bwrap.dom.appendChild(Ext.getDom('main-cs'));

        var appFocus = Ext.get('app-focus');
        appFocus.on('click', function(e){ e.stopEvent(); });

        /* WTF??
        $Mk.focus = function(){
            appFocus.focus();
        };
        */

    },

    afterRender : function(){
        Ext.ux.MainView.superclass.afterRender.call(this);

        Ext.EventManager.onWindowResize(this.handleSizeChange, this);
        if(Ext.isIE) {
            var view = this;
            this.minHeight = this.getMinHeight();

            setInterval(function(){
                if(view.layout.activeItem){
                    var h = Math.max(view.minHeight, view.layout.activeItem.el.getHeight());
                    view.body.setHeight(h > view.minHeight ? 'auto' : h);
                }
            }, 500);
        }

        this.handleSizeChange();
    },

    handleSizeChange : function(){
        var nw = this.getVisibleWidth();
        this.setWidth(nw - 5);
        this.minHeight = this.getMinHeight() - 5;
        if (!Ext.isIE) {
            this.body.setStyle('min-height', this.minHeight + 'px');
        }
    },

    getMinHeight: function(){
        return Ext.lib.Dom.getViewHeight() - /*50 hd+15 margins*/ 65;
    },

    getVisibleWidth: function(){
        var w = Ext.lib.Dom.getViewWidth();
        return w - 150;
    },

    /**
     * getCurrentView
     * returns current view id
     * @return {String} view id
     */
    getCurrentView : function() {
        return this.currentView;
    },

    /**
     * parseAction
     * splits a component's id on "-".  first chunk represents controller, second is component type
     * eg: "form", "list"
     * @param {Object} id
     */
    parseAction : function(id) {
        var path = id.match(/^(\w+)-(.*)/);
        if (path === null) {
            return alert("parseAction failed to parse id '" + id + "'");
        }
        return {
            controller: path[1],
            type: path[2]
        }
    }
});