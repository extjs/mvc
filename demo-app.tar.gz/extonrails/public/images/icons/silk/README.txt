Download silk icons from famfamfam.  Place the icon files in *this* directory.
